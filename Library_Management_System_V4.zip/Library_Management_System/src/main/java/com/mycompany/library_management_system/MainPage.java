// MAIN PAGE

package com.mycompany.library_management_system;

// Import all necessary class for functionalities
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class MainPage extends javax.swing.JFrame {

    public MainPage() {
        Color defaultColor = new Color(204, 204, 255);
        Color selectedColor = Color.GREEN;
        
        initComponents(); //Initialize then add all Components to Frame
        
        // Load Books and Members Details in their Tables at Start and During the Program
        loadBooksDetails();
        loadMembersDetails();
        loadIssuedBooksDetails();
        
        //Sort Table by ID in Ascending Order
        sortMembersDetailsTable(); 
        sortBooksDetailsTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titlePanel = new javax.swing.JPanel();
        adminLabel = new javax.swing.JLabel();
        librarianLabel = new javax.swing.JLabel();
        navigationPanel = new javax.swing.JPanel();
        dashboardButton = new javax.swing.JButton();
        featuresLabel = new javax.swing.JLabel();
        manageBooksButton = new javax.swing.JButton();
        manageMembersButton = new javax.swing.JButton();
        issueBookButton = new javax.swing.JButton();
        returnBookButton = new javax.swing.JButton();
        viewIssuedBooksButton = new javax.swing.JButton();
        logoutButton = new javax.swing.JButton();
        dashboardPanel = new javax.swing.JPanel();
        noOfBooksLabel = new javax.swing.JLabel();
        bookQuantityPanel = new javax.swing.JPanel();
        uniqueBookQuantityLabel = new javax.swing.JLabel();
        noOfMembersLabel = new javax.swing.JLabel();
        memberQuantityPanel = new javax.swing.JPanel();
        memberQuantityLabel = new javax.swing.JLabel();
        noOfIssuedBooksLabel = new javax.swing.JLabel();
        issuedBooksQuantityPanel = new javax.swing.JPanel();
        issuedBooksQuantityLabel = new javax.swing.JLabel();
        memberDetailsLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        membersDetailsTable = new javax.swing.JTable();
        bookDetailsLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        booksDetailsTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        titlePanel.setBackground(new java.awt.Color(102, 102, 255));

        adminLabel.setBackground(new java.awt.Color(204, 204, 255));
        adminLabel.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        adminLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        adminLabel.setText("Welcome Admin");
        adminLabel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        librarianLabel.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        librarianLabel.setText("Librarian");

        navigationPanel.setBackground(new java.awt.Color(0, 0, 204));

        dashboardButton.setBackground(java.awt.Color.green);
        dashboardButton.setText("Dashboard");
        dashboardButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashboardButtonActionPerformed(evt);
            }
        });

        featuresLabel.setForeground(new java.awt.Color(255, 255, 255));
        featuresLabel.setText("Features");

        manageBooksButton.setBackground(new java.awt.Color(204, 204, 255));
        manageBooksButton.setText("Manage Books");
        manageBooksButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manageBooksButtonActionPerformed(evt);
            }
        });

        manageMembersButton.setBackground(new java.awt.Color(204, 204, 255));
        manageMembersButton.setText("Manage Members");
        manageMembersButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manageMembersButtonActionPerformed(evt);
            }
        });

        issueBookButton.setBackground(new java.awt.Color(204, 204, 255));
        issueBookButton.setText("Issue Book");
        issueBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                issueBookButtonActionPerformed(evt);
            }
        });

        returnBookButton.setBackground(new java.awt.Color(204, 204, 255));
        returnBookButton.setText("Return Book");
        returnBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                returnBookButtonActionPerformed(evt);
            }
        });

        viewIssuedBooksButton.setBackground(new java.awt.Color(204, 204, 255));
        viewIssuedBooksButton.setText("View Issued Books");
        viewIssuedBooksButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewIssuedBooksButtonActionPerformed(evt);
            }
        });

        logoutButton.setBackground(new java.awt.Color(255, 204, 204));
        logoutButton.setText("Logout");
        logoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout navigationPanelLayout = new javax.swing.GroupLayout(navigationPanel);
        navigationPanel.setLayout(navigationPanelLayout);
        navigationPanelLayout.setHorizontalGroup(
            navigationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navigationPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(navigationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dashboardButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(manageBooksButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(manageMembersButton, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                    .addComponent(issueBookButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(returnBookButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(viewIssuedBooksButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(navigationPanelLayout.createSequentialGroup()
                        .addComponent(featuresLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(logoutButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        navigationPanelLayout.setVerticalGroup(
            navigationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navigationPanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(dashboardButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(featuresLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(manageBooksButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(manageMembersButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(issueBookButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(returnBookButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(viewIssuedBooksButton)
                .addGap(27, 27, 27)
                .addComponent(logoutButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        noOfBooksLabel.setText("No. of Books");

        bookQuantityPanel.setBackground(new java.awt.Color(204, 204, 204));

        uniqueBookQuantityLabel.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        uniqueBookQuantityLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        uniqueBookQuantityLabel.setText("0");

        javax.swing.GroupLayout bookQuantityPanelLayout = new javax.swing.GroupLayout(bookQuantityPanel);
        bookQuantityPanel.setLayout(bookQuantityPanelLayout);
        bookQuantityPanelLayout.setHorizontalGroup(
            bookQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(uniqueBookQuantityLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        bookQuantityPanelLayout.setVerticalGroup(
            bookQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(uniqueBookQuantityLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
        );

        noOfMembersLabel.setText("No. of Members");

        memberQuantityPanel.setBackground(new java.awt.Color(204, 204, 204));

        memberQuantityLabel.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        memberQuantityLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        memberQuantityLabel.setText("0");

        javax.swing.GroupLayout memberQuantityPanelLayout = new javax.swing.GroupLayout(memberQuantityPanel);
        memberQuantityPanel.setLayout(memberQuantityPanelLayout);
        memberQuantityPanelLayout.setHorizontalGroup(
            memberQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(memberQuantityLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE)
        );
        memberQuantityPanelLayout.setVerticalGroup(
            memberQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(memberQuantityLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        noOfIssuedBooksLabel.setText("Issued Books");

        issuedBooksQuantityPanel.setBackground(new java.awt.Color(204, 204, 204));

        issuedBooksQuantityLabel.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        issuedBooksQuantityLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        issuedBooksQuantityLabel.setText("0");

        javax.swing.GroupLayout issuedBooksQuantityPanelLayout = new javax.swing.GroupLayout(issuedBooksQuantityPanel);
        issuedBooksQuantityPanel.setLayout(issuedBooksQuantityPanelLayout);
        issuedBooksQuantityPanelLayout.setHorizontalGroup(
            issuedBooksQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(issuedBooksQuantityLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE)
        );
        issuedBooksQuantityPanelLayout.setVerticalGroup(
            issuedBooksQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(issuedBooksQuantityLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );

        memberDetailsLabel.setText("Member Details");

        membersDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Member ID", "Name", "Course", "Branch"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        membersDetailsTable.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        membersDetailsTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        membersDetailsTable.getTableHeader().setResizingAllowed(false);
        membersDetailsTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(membersDetailsTable);
        if (membersDetailsTable.getColumnModel().getColumnCount() > 0) {
            membersDetailsTable.getColumnModel().getColumn(0).setResizable(false);
            membersDetailsTable.getColumnModel().getColumn(1).setResizable(false);
            membersDetailsTable.getColumnModel().getColumn(2).setResizable(false);
            membersDetailsTable.getColumnModel().getColumn(3).setResizable(false);
        }

        bookDetailsLabel.setText("Book Details");

        booksDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Title", "Author", "Quantity"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        booksDetailsTable.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        booksDetailsTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        booksDetailsTable.getTableHeader().setResizingAllowed(false);
        booksDetailsTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(booksDetailsTable);
        if (booksDetailsTable.getColumnModel().getColumnCount() > 0) {
            booksDetailsTable.getColumnModel().getColumn(0).setResizable(false);
            booksDetailsTable.getColumnModel().getColumn(1).setResizable(false);
            booksDetailsTable.getColumnModel().getColumn(2).setResizable(false);
            booksDetailsTable.getColumnModel().getColumn(3).setResizable(false);
        }

        javax.swing.GroupLayout dashboardPanelLayout = new javax.swing.GroupLayout(dashboardPanel);
        dashboardPanel.setLayout(dashboardPanelLayout);
        dashboardPanelLayout.setHorizontalGroup(
            dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dashboardPanelLayout.createSequentialGroup()
                        .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(noOfBooksLabel)
                            .addComponent(bookQuantityPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(141, 141, 141)
                        .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(noOfMembersLabel)
                            .addComponent(memberQuantityPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 141, Short.MAX_VALUE)
                        .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(issuedBooksQuantityPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(noOfIssuedBooksLabel)))
                    .addComponent(jScrollPane1)
                    .addComponent(jScrollPane2)
                    .addGroup(dashboardPanelLayout.createSequentialGroup()
                        .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(memberDetailsLabel)
                            .addComponent(bookDetailsLabel))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        dashboardPanelLayout.setVerticalGroup(
            dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(noOfBooksLabel)
                    .addComponent(noOfMembersLabel)
                    .addComponent(noOfIssuedBooksLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(dashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(bookQuantityPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(memberQuantityPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(issuedBooksQuantityPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(memberDetailsLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bookDetailsLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(332, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout titlePanelLayout = new javax.swing.GroupLayout(titlePanel);
        titlePanel.setLayout(titlePanelLayout);
        titlePanelLayout.setHorizontalGroup(
            titlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, titlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(librarianLabel)
                .addGap(569, 569, 569)
                .addComponent(adminLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, titlePanelLayout.createSequentialGroup()
                .addComponent(navigationPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(dashboardPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        titlePanelLayout.setVerticalGroup(
            titlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titlePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(titlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminLabel)
                    .addComponent(librarianLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(titlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(dashboardPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(navigationPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(titlePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(titlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 549, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void manageBooksButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageBooksButtonActionPerformed
        // Redirect to Manage Books Page
        ManageBooksPage manageBooksPage = new ManageBooksPage();
        manageBooksPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_manageBooksButtonActionPerformed

    private void dashboardButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardButtonActionPerformed
        //Inform User that they are already in dashboard
        JOptionPane.showMessageDialog(null, "You Are Already In Dashboard");
    }//GEN-LAST:event_dashboardButtonActionPerformed

    private void manageMembersButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageMembersButtonActionPerformed
        // Redirect to Manage Members Page
        ManageMembersPage manageMembersPage = new ManageMembersPage();
        manageMembersPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_manageMembersButtonActionPerformed

    private void issueBookButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_issueBookButtonActionPerformed
        // Redirect to Issue Books Page
        IssueBooksPage issueBooksPage = new IssueBooksPage();
        issueBooksPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_issueBookButtonActionPerformed

    private void returnBookButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_returnBookButtonActionPerformed
        // Redirect to Return Books Page
        ReturnBooksPage returnBooksPage = new ReturnBooksPage();
        returnBooksPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_returnBookButtonActionPerformed

    private void viewIssuedBooksButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewIssuedBooksButtonActionPerformed
        // Redirect to View Issued Books Page
        ViewIssuedBooksPage viewIssuedBooksPage = new ViewIssuedBooksPage();
        viewIssuedBooksPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_viewIssuedBooksButtonActionPerformed

    private void logoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutButtonActionPerformed
        // REDIRECT TO LOGIN PAGE
        LoginPage loginPage = new LoginPage();
        loginPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutButtonActionPerformed
       
    private void loadBooksDetails(){
        // LOAD BOOKS DETAILS IN TABLE
        DefaultTableModel model = (DefaultTableModel) booksDetailsTable.getModel(); // Get Table Model
        model.setRowCount(0); //Initialize Rows
        
        int uniqueBookQuantity = 0; // Total Book Quantity
        try (BufferedReader bReader = new BufferedReader(new FileReader("booksDetails.txt"))){
            String line;
            while ((line = bReader.readLine()) != null){ //Read each line
                uniqueBookQuantity += 1; //Track Book Quantity
                String[] bookDetails = line.split(","); // Split the CSV
                
                model.addRow(new Object[]{bookDetails[0].trim(), bookDetails[1].trim(),
                                          bookDetails[2].trim(), bookDetails[3].trim()}); //Add data to new row in the table
                
            }
        }catch (IOException e){ //Catch any Error, then inform user that it occured
            JOptionPane.showMessageDialog(null, "Error Loading Book Details: "+e,
                                          "Loading Error", JOptionPane.ERROR_MESSAGE);
        }
        
        uniqueBookQuantityLabel.setText(Integer.toString(uniqueBookQuantity)); //Formats the Text in the Label for Book Quantity
    } 
    
    private void loadMembersDetails(){
        // LOAD MEMBERS DETAILS IN TABLE
        DefaultTableModel model = (DefaultTableModel) membersDetailsTable.getModel(); //Get Table Model
        model.setRowCount(0); //Reset Row Count
        
        int memberQuantity = 0; // Total Members Quantity
        try (BufferedReader bReader = new BufferedReader(new FileReader("membersDetails.txt"))){
            String line;
            while ((line = bReader.readLine()) != null){  //Read each line
                memberQuantity += 1; //Track Member Quantity
                String [] bookDetails = line.split(","); // Split the CSV
                
                model.addRow(new Object[]{bookDetails[0].trim(), bookDetails[1].trim(),
                                          bookDetails[2].trim(), bookDetails[3].trim()}); //Add data to new row in the table
                
            }
        }catch (IOException e){ //Catch any Error, then show that it occured to user
            JOptionPane.showMessageDialog(null, "Error Loading Member Details: "+e,
                                          "Loading Error", JOptionPane.ERROR_MESSAGE);
        }
        
        memberQuantityLabel.setText(Integer.toString(memberQuantity)); //Formats the Text in the Label for Member Quantity
    }
    
    private void loadIssuedBooksDetails(){
        // LOAD ISSUED BOOKS QUANTITY IN LABEL
        int issuedBooksQuantity = 0; // Tracks total Issued Books Quantity
        try (BufferedReader bReader = new BufferedReader(new FileReader("issuedBooksDetails.txt"))){
            while ((bReader.readLine()) != null){ //Iterate through each line of the file to count the no. of issued books
                issuedBooksQuantity += 1;
            }
        } catch (IOException e){ //Inform user of any error
            JOptionPane.showMessageDialog(null, "Error Loading Issued Books Details: "+e,
                                          "Loading Error", JOptionPane.ERROR_MESSAGE);
        }
        issuedBooksQuantityLabel.setText(Integer.toString(issuedBooksQuantity)); //Update Label of Tot. Issued Books Quantity
    }
    
    private void sortBooksDetailsTable(){
        //SORT BOOKS DETAILS TABLE
        // Create TableRowSorter for the Table's Model
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(booksDetailsTable.getModel());
        booksDetailsTable.setRowSorter(sorter); // Set sorter for the table

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();//List of RowSorter.SortKey, defines the column and sorting order
        int columnIndexToSort = 0; // Index of the column to sort
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING)); // Sort in ascending order

        // Apply Sort Keys
        sorter.setSortKeys(sortKeys);
        sorter.sort(); // Sort the rows
        
        //Inhibit Sorting at Column 1-3
        sorter.setSortable(1, false);
        sorter.setSortable(2, false);
        sorter.setSortable(3, false);
    }
    
    private void sortMembersDetailsTable(){
        //SORT BOOKS DETAILS TABLE
        // Create TableRowSorter for the Table's Model
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(membersDetailsTable.getModel());
        membersDetailsTable.setRowSorter(sorter); // Set sorter for the table

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();//List of RowSorter.SortKey, defines the column and sorting order
        int columnIndexToSort = 0; // Index of the column to sort
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING)); // Sort in ascending order

        // Apply Sort Keys
        sorter.setSortKeys(sortKeys);
        sorter.sort(); // Sort the rows
        
        //Inhibit Sorting at Column 1-3
        sorter.setSortable(1, false);
        sorter.setSortable(2, false);
        sorter.setSortable(3, false);
    }
    
    /**
     * @param args the command line arguments
     */    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel adminLabel;
    private javax.swing.JLabel bookDetailsLabel;
    private javax.swing.JPanel bookQuantityPanel;
    private javax.swing.JTable booksDetailsTable;
    private javax.swing.JButton dashboardButton;
    private javax.swing.JPanel dashboardPanel;
    private javax.swing.JLabel featuresLabel;
    private javax.swing.JButton issueBookButton;
    private javax.swing.JLabel issuedBooksQuantityLabel;
    private javax.swing.JPanel issuedBooksQuantityPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel librarianLabel;
    private javax.swing.JButton logoutButton;
    private javax.swing.JButton manageBooksButton;
    private javax.swing.JButton manageMembersButton;
    private javax.swing.JLabel memberDetailsLabel;
    private javax.swing.JLabel memberQuantityLabel;
    private javax.swing.JPanel memberQuantityPanel;
    private javax.swing.JTable membersDetailsTable;
    private javax.swing.JPanel navigationPanel;
    private javax.swing.JLabel noOfBooksLabel;
    private javax.swing.JLabel noOfIssuedBooksLabel;
    private javax.swing.JLabel noOfMembersLabel;
    private javax.swing.JButton returnBookButton;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JLabel uniqueBookQuantityLabel;
    private javax.swing.JButton viewIssuedBooksButton;
    // End of variables declaration//GEN-END:variables
}
