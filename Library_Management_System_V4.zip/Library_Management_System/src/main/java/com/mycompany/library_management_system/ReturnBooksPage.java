//RETURN BOOKS PAGE

package com.mycompany.library_management_system;

//Import All Necessary Classes For Functionalities
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class ReturnBooksPage extends javax.swing.JFrame {

    public ReturnBooksPage() {
        initComponents(); //Initialize then add all Components to Frame
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bookIDLabel = new javax.swing.JLabel();
        bookIDTextField = new javax.swing.JTextField();
        memberIDLabel = new javax.swing.JLabel();
        memberIDTextField = new javax.swing.JTextField();
        findDetailsButton = new javax.swing.JButton();
        returnBookButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        returnBooksTitleLabel = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        bookDetailsTextArea = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        memberDetailsTextArea = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 205));

        bookIDLabel.setForeground(new java.awt.Color(255, 255, 255));
        bookIDLabel.setText("Enter Book ID:");

        memberIDLabel.setForeground(new java.awt.Color(255, 255, 255));
        memberIDLabel.setText("Enter Member ID:");

        findDetailsButton.setText("FIND DETAILS");
        findDetailsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findDetailsButtonActionPerformed(evt);
            }
        });

        returnBookButton.setText("RETURN BOOK");
        returnBookButton.setEnabled(false);
        returnBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                returnBookButtonActionPerformed(evt);
            }
        });

        backButton.setText("Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        returnBooksTitleLabel.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        returnBooksTitleLabel.setForeground(new java.awt.Color(255, 255, 255));
        returnBooksTitleLabel.setText("Return Books");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bookIDTextField)
                    .addComponent(memberIDTextField)
                    .addComponent(findDetailsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(returnBookButton, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bookIDLabel)
                            .addComponent(memberIDLabel)
                            .addComponent(returnBooksTitleLabel))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(backButton)
                .addGap(18, 18, 18)
                .addComponent(returnBooksTitleLabel)
                .addGap(60, 60, 60)
                .addComponent(bookIDLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(memberIDLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(memberIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73)
                .addComponent(findDetailsButton)
                .addGap(18, 18, 18)
                .addComponent(returnBookButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 0, 0));

        jLabel1.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Book Details");

        bookDetailsTextArea.setColumns(20);
        bookDetailsTextArea.setRows(5);
        bookDetailsTextArea.setText("Book ID:\n\n\nBook Title:\n\n\nIssued Date:\n\n\nDue Date:\n\n\n");
        jScrollPane1.setViewportView(bookDetailsTextArea);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(104, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(98, 98, 98))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 255, 0));

        jLabel2.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Member Details");

        memberDetailsTextArea.setColumns(20);
        memberDetailsTextArea.setRows(5);
        memberDetailsTextArea.setText("Member ID:\n\n\nMember Name:\n\n\nCourse:\n\n");
        jScrollPane2.setViewportView(memberDetailsTextArea);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(66, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(58, 58, 58))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(115, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void findDetailsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findDetailsButtonActionPerformed
        // FIND DETAILS OF BORROWED BOOK AND THE MEMBER THAT BORROWED IT
        //Get Book/Member ID
        String bookID = bookIDTextField.getText();
        String memberID = memberIDTextField.getText();
        
        String[] issuedBooksDetails = null; //Initialize issuedBooksDetails
        if (!anyEmpty(Arrays.asList(bookID, memberID))){ //Check if Any of Book/Member ID is Not Empty
            try (BufferedReader bReader = new BufferedReader(new FileReader("issuedBooksDetails.txt"))){
                String line;
                while((line = bReader.readLine()) != null){
                    String[] lineDetails = line.split(",");
                    
                    //Check if Recorded Member/Book ID is same as Input
                    if (lineDetails[1].equals(memberID) && lineDetails[4].equals(bookID)){  
                         issuedBooksDetails = lineDetails; //Declare issuedBooksDetails same as current line details
                         break; //Break loop since it is Already Found
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Member or Book Details Not Found: "+e,
                                               "Search Error", JOptionPane.ERROR_MESSAGE);
                return; //Early Return Since There is Search Error
            }
        }
        
        if (issuedBooksDetails != null){ //Check if issuedBooksDetails is not Null
            //Format Book/Member Details for Easier Setting of Text In Label
            String formattedBookDetailsText = String.format("Book ID:%n%s%n%nBook Title:%n%s%n%nIssued Date:%n%s%n%nDue Date:%n%s%n%n", 
                                                        issuedBooksDetails[3], issuedBooksDetails[4],
                                                        issuedBooksDetails[5], issuedBooksDetails[6]);
            String formattedMemberDetailsText = String.format("Member ID:%n%s%n%nMember Name:%n%s%n%nCourse:%n%s%n%n", 
                                                              issuedBooksDetails[1], issuedBooksDetails[0],
                                                              issuedBooksDetails[2]);
            
            //Set Text of Label as the Formatted Book/Member Details
            bookDetailsTextArea.setText(formattedBookDetailsText);
            memberDetailsTextArea.setText(formattedMemberDetailsText);
            
            //Inform User of Search Success
            JOptionPane.showMessageDialog(null, "Issued Book and Member Details Found",
                                          "Search Success", JOptionPane.INFORMATION_MESSAGE);
            returnBookButton.setEnabled(true); //Enable Button Since Search is Success
            
        } else { //Inform User that Details Are Not Found
            JOptionPane.showMessageDialog(null, "Member or Book Details Not Found",
                                          "Search Error", JOptionPane.ERROR_MESSAGE);
        }       
    }//GEN-LAST:event_findDetailsButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // REDIRECT TO MAIN PAGE
        MainPage mainPage = new MainPage();
        mainPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    private void returnBookButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_returnBookButtonActionPerformed
        // UPDATE RETURNED BOOK IN ISSUED BOOKS RECORDS
        //Get book/member ID
        String bookID = bookIDTextField.getText();
        String memberID = memberIDTextField.getText();
        
        if(!anyEmpty(Arrays.asList(bookID, memberID))){ //Check if Any of Book/Member ID is Not Empty
            updateReturnBooksRecord(bookID, memberID); //Update Records of Returned Book
        } else { //Inform User of Input Error
            JOptionPane.showMessageDialog(null, "Please Fill All Required Fields",
                                          "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_returnBookButtonActionPerformed
    
    private void updateReturnBooksRecord(String bookID, String memberID) { 
        //UPDATES RETURNED BOOK RECORDS
        // Format Date
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date currentDate = new Date(); // Get the current date
        String formattedDate = formatter.format(currentDate); // Format the current date

        // Initialize Issued Books Temp/Orig File as well as Returned Books File
        File issuedBooksFile = new File("issuedBooksDetails.txt");
        File tempIssuedBooksFile = new File("tempIssuedBooksDetails.txt");
        File returnedBooksFile = new File("returnedBooksDetails.txt");

        boolean found = false; // Tracks if bookID and memberID is found

        try (BufferedReader bOrigReader = new BufferedReader(new FileReader(issuedBooksFile)); //Reads Orig Issued Books File
             BufferedWriter bTempWriter = new BufferedWriter(new FileWriter(tempIssuedBooksFile)); //Writes to Temp Issued Books File
             BufferedWriter bReturnedWriter = new BufferedWriter(new FileWriter(returnedBooksFile, true))) { //Appends to Returned Books File

            String line;

            while ((line = bOrigReader.readLine()) != null) { // Read OrigFile of Issued Books Records
                String[] lineDetails = line.split(",");

                // Check if recorded member/book ID is same as inputted
                if (lineDetails[1].equals(memberID) && lineDetails[4].equals(bookID)) {
                    found = true; // Update that it is found

                    // Check if Book has not been Returned
                    if (lineDetails[7].equals("null")) {
                        lineDetails[7] = formattedDate; // Update Returned Date Record
                        
                        // Move and Update the File in Returned Books Records
                        bReturnedWriter.write(String.join(",", lineDetails)); 
                        bReturnedWriter.newLine();

                        updateReturnedBookQuantity(bookID); // Update Quantity in Books Records
                    }
                    
                } else {
                    // Write the line to the temporary file
                    bTempWriter.write(line);
                    bTempWriter.newLine();
                }
            }

        } catch (IOException e) { 
            JOptionPane.showMessageDialog(null, "Error Returning Book: " + e, 
                                          "Return Error", JOptionPane.ERROR_MESSAGE);
            return; //Early Return Since there is Return Error
        }

        // After processing, delete the original file and rename temp file
        if (found) {
            if (issuedBooksFile.delete()) { //Check if issuedBooksFile can be Deleted
                tempIssuedBooksFile.renameTo(issuedBooksFile); //Rename Temp File same as Orig Issued Books File
                JOptionPane.showMessageDialog(null, "Issued Book Record Updated Successfully.",
                                              "Return Success", JOptionPane.INFORMATION_MESSAGE); //Inform User of Return Success
            } else { //Inform user of Deletion Error
                JOptionPane.showMessageDialog(null, "Original File Deletion Failed",
                                              "Deletion Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // Check if the book has already been returned in the returned books file
            try (BufferedReader bReturnedReader = new BufferedReader(new FileReader(returnedBooksFile))) {
                String line;
                while ((line = bReturnedReader.readLine()) != null) {
                    String[] lineDetails = line.split(",");
                    
                    //Check if Recorded Member/Book ID is same as Input
                    if (lineDetails[1].equals(memberID) && lineDetails[4].equals(bookID)) {
                        JOptionPane.showMessageDialog(null, "Book Has Already Been Returned",
                                                      "Already Returned", JOptionPane.ERROR_MESSAGE);
                        return; // Exit if already returned
                    }
                }
            } catch (IOException e) { 
                JOptionPane.showMessageDialog(null, "Error Checking Returned Books: " + e, 
                                              "Return Error", JOptionPane.ERROR_MESSAGE);
            }

            // Inform User that bookID and memberID is Not Found
            JOptionPane.showMessageDialog(null, "Book ID / Member ID Not Found in Records", 
                                          "Search Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateReturnedBookQuantity(String bookID){
        // UPDATE BOOK QUANTITY IN BOOK RECORDS
        String issuedQuantity = "1";
        String totalQuantity;
        
        //Initialize origFile and tempFile
        File origFile = new File("booksDetails.txt");
        File tempFile = new File("tempBooksDetails.txt"); 
        try (BufferedReader bReader = new BufferedReader(new FileReader(origFile));
             BufferedWriter bWriter = new BufferedWriter(new FileWriter(tempFile))){
            String line;
            boolean found = false; //Tracks if found
            while((line = bReader.readLine()) != null){
                String[] lineDetails = line.split(",");
                
                if (lineDetails[0].equals(bookID)){
                    //Add one from the original quantity since we are returning books
                    found = true; //update that it is found
                    totalQuantity = Integer.toString(Integer.parseInt(lineDetails[3]) + Integer.parseInt(issuedQuantity));
                    lineDetails[3] = totalQuantity; //Update the Quantity value

                    bWriter.write(String.join(",", lineDetails)); //Write updated line to file
                    bWriter.newLine(); //Add new line
                    continue; //Continue to next loop since current one is already written
                }
                //Write current line and add new line
                bWriter.write(line);
                bWriter.newLine();
                
            }
            
            //Close Reader and Writer to Allow File Deletion and Naming
            bReader.close();
            bWriter.close();
            
            if (found){ //Check if Found
                if (origFile.delete()){ //Check if original file can be deleted
                    tempFile.renameTo(origFile); //rename tempFile same as origFile
                    JOptionPane.showMessageDialog(null, "Returned Successfully",
                                                  "Return Success", JOptionPane.INFORMATION_MESSAGE); //Inform User of Return Success
                } else { //Inform user of Error Returning
                    JOptionPane.showMessageDialog(null, "Error Updating Book Quantity",
                                                  "Returning Failed", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            
        } catch (IOException e) { //Inform user of any Errors
            JOptionPane.showMessageDialog(null, "Error Returning Book: " + e,
                                          "Return Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private static boolean anyEmpty(List<String> strings){
        boolean hasEmpty = strings.stream() //List is Used for Easier Traversal and Checking
                                  .anyMatch(str -> str == null || str.trim().isEmpty()); //Checks if any of the values are null/empty
        
        return hasEmpty; //Returns True if Empty, False if Not Empty
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReturnBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReturnBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReturnBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReturnBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReturnBooksPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JTextArea bookDetailsTextArea;
    private javax.swing.JLabel bookIDLabel;
    private javax.swing.JTextField bookIDTextField;
    private javax.swing.JButton findDetailsButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea memberDetailsTextArea;
    private javax.swing.JLabel memberIDLabel;
    private javax.swing.JTextField memberIDTextField;
    private javax.swing.JButton returnBookButton;
    private javax.swing.JLabel returnBooksTitleLabel;
    // End of variables declaration//GEN-END:variables
}
