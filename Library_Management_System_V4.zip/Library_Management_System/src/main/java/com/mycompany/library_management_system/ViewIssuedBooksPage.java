//VIEW ISSUED BOOKS PAGE
package com.mycompany.library_management_system;

//Import All Necessary Classes For Functionalities
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class ViewIssuedBooksPage extends javax.swing.JFrame {

    public ViewIssuedBooksPage() {
        initComponents(); //Initialize then add all Components to Frame
        
        //Load and Sort Issued and Returned Books Details Table
        loadIssuedBooksDetails();
        loadReturnedBooksDetails();
        sortIssuedBooksDetailsTable();
        sortReturnedBooksDetailsTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        issuedBooksTitlePanel = new javax.swing.JPanel();
        issuedBooksTitleLabel = new javax.swing.JLabel();
        backButton = new javax.swing.JButton();
        mainPanel = new javax.swing.JPanel();
        issuedBooksDetailsTableScrollPane = new javax.swing.JScrollPane();
        issuedBooksDetailsTable = new javax.swing.JTable();
        returnedBooksTitlePanel = new javax.swing.JPanel();
        returnedBooksTitleLabel = new javax.swing.JLabel();
        returnedBooksTableScrollPane = new javax.swing.JScrollPane();
        returnedBooksDetailsTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        issuedBooksTitlePanel.setBackground(new java.awt.Color(0, 0, 205));

        issuedBooksTitleLabel.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        issuedBooksTitleLabel.setForeground(new java.awt.Color(255, 255, 255));
        issuedBooksTitleLabel.setText("Issued Books Record");

        backButton.setText("Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout issuedBooksTitlePanelLayout = new javax.swing.GroupLayout(issuedBooksTitlePanel);
        issuedBooksTitlePanel.setLayout(issuedBooksTitlePanelLayout);
        issuedBooksTitlePanelLayout.setHorizontalGroup(
            issuedBooksTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(issuedBooksTitlePanelLayout.createSequentialGroup()
                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(192, 192, 192)
                .addComponent(issuedBooksTitleLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        issuedBooksTitlePanelLayout.setVerticalGroup(
            issuedBooksTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(issuedBooksTitlePanelLayout.createSequentialGroup()
                .addGroup(issuedBooksTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(backButton)
                    .addGroup(issuedBooksTitlePanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(issuedBooksTitleLabel)))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        issuedBooksDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Member Name", "Member ID", "Course", "Book Borrowed", "Book ID", "Date Issued", "Due Date", "Date Returned"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        issuedBooksDetailsTable.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        issuedBooksDetailsTable.getTableHeader().setReorderingAllowed(false);
        issuedBooksDetailsTableScrollPane.setViewportView(issuedBooksDetailsTable);
        if (issuedBooksDetailsTable.getColumnModel().getColumnCount() > 0) {
            issuedBooksDetailsTable.getColumnModel().getColumn(0).setResizable(false);
            issuedBooksDetailsTable.getColumnModel().getColumn(1).setResizable(false);
            issuedBooksDetailsTable.getColumnModel().getColumn(2).setResizable(false);
            issuedBooksDetailsTable.getColumnModel().getColumn(3).setResizable(false);
            issuedBooksDetailsTable.getColumnModel().getColumn(4).setResizable(false);
            issuedBooksDetailsTable.getColumnModel().getColumn(5).setResizable(false);
            issuedBooksDetailsTable.getColumnModel().getColumn(6).setResizable(false);
            issuedBooksDetailsTable.getColumnModel().getColumn(7).setResizable(false);
        }

        returnedBooksTitlePanel.setBackground(new java.awt.Color(0, 0, 204));
        returnedBooksTitlePanel.setForeground(new java.awt.Color(0, 0, 204));

        returnedBooksTitleLabel.setBackground(new java.awt.Color(255, 255, 255));
        returnedBooksTitleLabel.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        returnedBooksTitleLabel.setForeground(new java.awt.Color(255, 255, 255));
        returnedBooksTitleLabel.setText("Returned Books Record");

        javax.swing.GroupLayout returnedBooksTitlePanelLayout = new javax.swing.GroupLayout(returnedBooksTitlePanel);
        returnedBooksTitlePanel.setLayout(returnedBooksTitlePanelLayout);
        returnedBooksTitlePanelLayout.setHorizontalGroup(
            returnedBooksTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(returnedBooksTitlePanelLayout.createSequentialGroup()
                .addGap(259, 259, 259)
                .addComponent(returnedBooksTitleLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        returnedBooksTitlePanelLayout.setVerticalGroup(
            returnedBooksTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(returnedBooksTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(returnedBooksTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        returnedBooksDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Memeber Name", "Member ID", "Course", "Book Borrowed", "Book ID", "Date Issued", "Due Date", "Date Returned"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        returnedBooksDetailsTable.getTableHeader().setReorderingAllowed(false);
        returnedBooksTableScrollPane.setViewportView(returnedBooksDetailsTable);
        if (returnedBooksDetailsTable.getColumnModel().getColumnCount() > 0) {
            returnedBooksDetailsTable.getColumnModel().getColumn(0).setResizable(false);
            returnedBooksDetailsTable.getColumnModel().getColumn(1).setResizable(false);
            returnedBooksDetailsTable.getColumnModel().getColumn(2).setResizable(false);
            returnedBooksDetailsTable.getColumnModel().getColumn(3).setResizable(false);
            returnedBooksDetailsTable.getColumnModel().getColumn(4).setResizable(false);
            returnedBooksDetailsTable.getColumnModel().getColumn(5).setResizable(false);
            returnedBooksDetailsTable.getColumnModel().getColumn(6).setResizable(false);
            returnedBooksDetailsTable.getColumnModel().getColumn(7).setResizable(false);
        }

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(returnedBooksTitlePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(issuedBooksDetailsTableScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 825, Short.MAX_VALUE)
                    .addComponent(returnedBooksTableScrollPane))
                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(issuedBooksDetailsTableScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(returnedBooksTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(returnedBooksTableScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(issuedBooksTitlePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(issuedBooksTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        //REDIRECT TO MAIN PAGE
        MainPage mainPage = new MainPage();
        mainPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed
    
    private void loadIssuedBooksDetails(){
        //LOAD ISSUED BOOKS RECORDS IN TABLE
        DefaultTableModel model = (DefaultTableModel) issuedBooksDetailsTable.getModel(); //Get Table Model
        model.setRowCount(0); //Reset Row Count
        
        try (BufferedReader bReader = new BufferedReader(new FileReader("issuedBooksDetails.txt"))){
            String line;
            while ((line = bReader.readLine()) != null){
                String [] issuedBookDetails = line.split(","); // Split the CSV
                
                //Add data to new row in the table
                model.addRow(new Object[]{issuedBookDetails[0].trim(), issuedBookDetails[1].trim(),
                                          issuedBookDetails[2].trim(), issuedBookDetails[3].trim(),
                                          issuedBookDetails[4].trim(), issuedBookDetails[5].trim(),
                                          issuedBookDetails[6].trim(), issuedBookDetails[7].trim()});
            }
            
        } catch (IOException e){ //Inform User of Loading Error
            JOptionPane.showMessageDialog(null, "Error Loading Issued Books Details: "+e,
                                          "Loading Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadReturnedBooksDetails(){
        //LOAD RETURNED BOOKS RECORDS IN TABLE
        DefaultTableModel model = (DefaultTableModel) returnedBooksDetailsTable.getModel(); //Get Table Model
        model.setRowCount(0); //Reset Row Count
        
        try (BufferedReader bReader = new BufferedReader(new FileReader("returnedBooksDetails.txt"))){
            String line;
            while ((line = bReader.readLine()) != null){
                String [] issuedBookDetails = line.split(","); // Split the CSV
                
                //Add data to new row in the table
                model.addRow(new Object[]{issuedBookDetails[0].trim(), issuedBookDetails[1].trim(),
                                          issuedBookDetails[2].trim(), issuedBookDetails[3].trim(),
                                          issuedBookDetails[4].trim(), issuedBookDetails[5].trim(),
                                          issuedBookDetails[6].trim(), issuedBookDetails[7].trim()}); 
            } 
        } catch (IOException e){ //Inform User of Loading Error
            JOptionPane.showMessageDialog(null, "Error Loading Returned Books Details: "+e,
                                          "Loading Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void sortIssuedBooksDetailsTable(){
        //SORT ISSUED BOOKS DETAILS TABLE
        // Create TableRowSorter for the Table's Model
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(issuedBooksDetailsTable.getModel());
        issuedBooksDetailsTable.setRowSorter(sorter); // Set sorter for the table

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();//List of RowSorter.SortKey, defines the column and sorting order
        int columnIndexToSort = 1; // Index of the column to sort
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING)); // Sort in ascending order

        // Apply Sort Keys
        sorter.setSortKeys(sortKeys);
        sorter.sort(); // Sort the rows
        
        //Inhibit Sorting at Column 0, 4
        sorter.setSortable(0, false);
        sorter.setSortable(4, false);
    }
    
    private void sortReturnedBooksDetailsTable(){
        //SORT RETURNED BOOKS DETAILS TABLE
        // Create TableRowSorter for the Table's Model
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(returnedBooksDetailsTable.getModel());
        returnedBooksDetailsTable.setRowSorter(sorter); // Set sorter for the table

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();//List of RowSorter.SortKey, defines the column and sorting order
        int columnIndexToSort = 1; // Index of the column to sort
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING)); // Sort in ascending order

        // Apply Sort Keys
        sorter.setSortKeys(sortKeys);
        sorter.sort(); // Sort the rows
        
        //Inhibit Sorting at Column 0, 4
        sorter.setSortable(0, false);
        sorter.setSortable(4, false);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewIssuedBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewIssuedBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewIssuedBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewIssuedBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewIssuedBooksPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JTable issuedBooksDetailsTable;
    private javax.swing.JScrollPane issuedBooksDetailsTableScrollPane;
    private javax.swing.JLabel issuedBooksTitleLabel;
    private javax.swing.JPanel issuedBooksTitlePanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JTable returnedBooksDetailsTable;
    private javax.swing.JScrollPane returnedBooksTableScrollPane;
    private javax.swing.JLabel returnedBooksTitleLabel;
    private javax.swing.JPanel returnedBooksTitlePanel;
    // End of variables declaration//GEN-END:variables
}
