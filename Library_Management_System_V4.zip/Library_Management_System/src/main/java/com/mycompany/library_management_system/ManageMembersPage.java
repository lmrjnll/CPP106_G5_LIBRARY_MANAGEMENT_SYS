//MANAGE MEMBERS PAGE

package com.mycompany.library_management_system;

//Import All Necessary Classes for Functionalities
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class ManageMembersPage extends javax.swing.JFrame {

    public ManageMembersPage() {
        initComponents(); //Initialize then add all Components to Frame
               
        loadMembersDetails(); //Load Previously Saved Member Data
        sortMembersDetailsTable(); //Sort Table by ID in Ascending Order
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        manageMembersPanel = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        memberIDLabel = new javax.swing.JLabel();
        memberNameLabel = new javax.swing.JLabel();
        memberIDTextField = new javax.swing.JTextField();
        memberNameTextField = new javax.swing.JTextField();
        courseLabel = new javax.swing.JLabel();
        branchLabel = new javax.swing.JLabel();
        branchTextField = new javax.swing.JTextField();
        addButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        courseComboBox = new javax.swing.JComboBox<>();
        mainManageMembersPanel = new javax.swing.JPanel();
        manageMembersTitleLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        membersDetailsTable = new javax.swing.JTable();
        tipLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(0, 0, 835, 505));
        setSize(new java.awt.Dimension(835, 505));

        manageMembersPanel.setBackground(new java.awt.Color(0, 0, 204));

        backButton.setText("Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        memberIDLabel.setForeground(new java.awt.Color(255, 255, 255));
        memberIDLabel.setText("Enter Member ID:");

        memberNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        memberNameLabel.setText("Enter Member 's Name:");

        courseLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseLabel.setText("Enter Course:");

        branchLabel.setForeground(new java.awt.Color(255, 255, 255));
        branchLabel.setText("Enter Branch:");

        addButton.setText("ADD");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("DELETE");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        courseComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "  ", "COE", "CBAA", "CHAS", "CCS", "COED" }));

        javax.swing.GroupLayout manageMembersPanelLayout = new javax.swing.GroupLayout(manageMembersPanel);
        manageMembersPanel.setLayout(manageMembersPanelLayout);
        manageMembersPanelLayout.setHorizontalGroup(
            manageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manageMembersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(branchLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(manageMembersPanelLayout.createSequentialGroup()
                .addGroup(manageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(manageMembersPanelLayout.createSequentialGroup()
                        .addGroup(manageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(manageMembersPanelLayout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(addButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteButton))
                            .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 30, Short.MAX_VALUE))
                    .addGroup(manageMembersPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(manageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(memberNameTextField)
                            .addComponent(memberIDTextField)
                            .addGroup(manageMembersPanelLayout.createSequentialGroup()
                                .addGroup(manageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(memberIDLabel)
                                    .addComponent(memberNameLabel)
                                    .addComponent(courseLabel))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(branchTextField)
                            .addComponent(courseComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        manageMembersPanelLayout.setVerticalGroup(
            manageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manageMembersPanelLayout.createSequentialGroup()
                .addComponent(backButton)
                .addGap(57, 57, 57)
                .addComponent(memberIDLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(memberIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(memberNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(memberNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(courseLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(branchLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(branchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(manageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addButton)
                    .addComponent(deleteButton))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        manageMembersTitleLabel.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        manageMembersTitleLabel.setText("MANAGE MEMBERS");

        membersDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Member ID", "Name", "Course", "Branch"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        membersDetailsTable.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        membersDetailsTable.setName(""); // NOI18N
        membersDetailsTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(membersDetailsTable);
        if (membersDetailsTable.getColumnModel().getColumnCount() > 0) {
            membersDetailsTable.getColumnModel().getColumn(0).setResizable(false);
            membersDetailsTable.getColumnModel().getColumn(1).setResizable(false);
            membersDetailsTable.getColumnModel().getColumn(2).setResizable(false);
            membersDetailsTable.getColumnModel().getColumn(3).setResizable(false);
        }

        javax.swing.GroupLayout mainManageMembersPanelLayout = new javax.swing.GroupLayout(mainManageMembersPanel);
        mainManageMembersPanel.setLayout(mainManageMembersPanelLayout);
        mainManageMembersPanelLayout.setHorizontalGroup(
            mainManageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainManageMembersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainManageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainManageMembersPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(manageMembersTitleLabel)
                        .addGap(179, 179, 179))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        mainManageMembersPanelLayout.setVerticalGroup(
            mainManageMembersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainManageMembersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(manageMembersTitleLabel)
                .addGap(43, 43, 43)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tipLabel.setText("Tip: Press Table Header to Sort Column");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(manageMembersPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mainManageMembersPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tipLabel)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(manageMembersPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(mainManageMembersPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 97, Short.MAX_VALUE)
                .addComponent(tipLabel)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        //REDIRECT TO MAIN PAGE
        MainPage mainPage = new MainPage();
        mainPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // ADD MEMBER TO TABLE AND FILE
        DefaultTableModel model = (DefaultTableModel) membersDetailsTable.getModel(); // Get Table Model
        
        // Get Member Details
        String memberID = memberIDTextField.getText();
        String memberName = memberNameTextField.getText();
        String course = courseComboBox.getSelectedItem().toString();
        String branch = branchTextField.getText();
        
        // Convert to List for Easy Processing and Traversal
        List memberDetailsValues = Arrays.asList(memberID, memberName, course, branch);
        
        if (!anyEmpty(memberDetailsValues)){ //Check if any of the fields are not empty
            saveMemberDetails(memberDetailsValues); //Save Member Details to File
            model.addRow(new Object []{memberID, memberName, course, branch}); //Add Member Details to Table
            
        } else { //Urge User to Fill All The Required Fields
            JOptionPane.showMessageDialog(null, "Fill All Required Fields!", "Input Error", JOptionPane.ERROR_MESSAGE);
        } 
    }//GEN-LAST:event_addButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        //REMOVE MEMBER IN TABLE AND FILE
        DefaultTableModel model = (DefaultTableModel) membersDetailsTable.getModel(); //Get Table Model
        
        if (membersDetailsTable.getSelectedRow() != -1){ //Check if Any Row is Currently Selected    
            //Show Sorting Warning
            JOptionPane.showMessageDialog(null, "Sorting Table Might Cause Deletion Error\nIf You Have Sorted Table, Please Press Back To Reset Table",
                                          "Sort Warning", JOptionPane.WARNING_MESSAGE);
            //Ask for Delete Confirmaation
            int input = JOptionPane.showConfirmDialog(null, "Delete Member's Data?", 
                                                      "Deletion Confirmation", JOptionPane.YES_NO_CANCEL_OPTION);
            
            if (input==0){ //Check if User Confirmed, (0 = Yes , 1 = No , 2 = Cancel)
                deleteMemberDetails(membersDetailsTable.getSelectedRow()); //Delete Book in File
                model.removeRow(membersDetailsTable.getSelectedRow()); //Remove Book in Table          
            } 
            
        } else { //Inform User that They Need To Select A Book to be Deleted
            JOptionPane.showMessageDialog(null, "Please Select A Member To Be Deleted", "Select Book", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_deleteButtonActionPerformed
    
    private static boolean anyEmpty(List<String> strings){
        boolean hasEmpty = strings.stream() //List is Used for Easier Traversal and Checking
                                  .anyMatch(str -> str == null || str.trim().isEmpty()); //Checks if any of the values are null/empty
        
        return hasEmpty; //Returns True if Empty, False if Not Empty
    }
    
    private String getRowData(int selectedRow){
        //CONVERTS DATA IN ROW TO A CSV DATA
        DefaultTableModel model = (DefaultTableModel) membersDetailsTable.getModel(); //Get Table Model
        
        int[] columns = {0,1,2,3}; //No. of Fixed Columns
        String[] values = new String[columns.length]; //Makes a List of Values in Each Column in a Specific Row
        
        int i = 0; //Tracks Iteration
        for (int column : columns){
            values[i] = model.getValueAt(selectedRow, column).toString(); //Obtains Value at the Target Cell (Row and Column)
            i += 1;
        }
        
        String joinedValues = String.join(",", values); //Converts the List into a CSV
        return joinedValues; //Return CSV
    }
    
    private void saveMemberDetails(List<String> bookDetails){
        //SAVE MEMBERS DETAILS IN FILE
        
        try (BufferedWriter bWriter = new BufferedWriter(new FileWriter("membersDetails.txt", true))){
            bWriter.write(String.join(",", bookDetails)); //Saves Member Details in CSV Format in File 
            bWriter.newLine(); //Adds New Line
            
        } catch (IOException e){ //Inform User Errors in Saving
            JOptionPane.showMessageDialog(null, "Error Saving Member Details: "+e,
                                          "Saving Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        //Inform user of Successful Saving
        JOptionPane.showMessageDialog(null, "Member Data Saved Successfully", 
                                      "Saved Successfully", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void deleteMemberDetails(int selectedRow){
        //DELETE MEMBER DETAILS IN FILE
        String joinedRowData = getRowData(selectedRow); //Obtains the Selected Row in the Table
        
        //Initialize the Orignal and Temporary File
        File originalFile = new File("membersDetails.txt");
        File tempFile = new File("tempMembersDetails.txt");
        try (BufferedReader bReader = new BufferedReader(new FileReader(originalFile));
             BufferedWriter bWriter = new BufferedWriter(new FileWriter(tempFile))){
            
            String line;
            boolean found = false; //Tracks if the target data is found or not
            
            while ((line = bReader.readLine()) != null){
                if (line.equals(joinedRowData)){ //Checks if the line is the same as the CSV Formatted one
                    found = true; //If found then skip this line and continue to the next since we are deleting it
                    continue;
                }
                bWriter.write(line); //If not found then writes the current line in the temporary file
                bWriter.newLine();
            }
            // Close BufferedReader and BufferedWriter to avoid errors in deletion and renaming
            bReader.close();
            bWriter.close();
            
            if(found){ //Checks if Target Data is Found
                if(originalFile.delete()){ //Checks if Orignal File can be deleted, if it can, proceeds to delete it
                    tempFile.renameTo(originalFile); //Rename Temporary File the same as the Original File
                    //Inform User that Deletion is a Success
                    JOptionPane.showMessageDialog(null, "Member Data Deleted Successfully!",
                                                  "Deletion Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // Inform User that Error Occured in Proper Deletion
                    JOptionPane.showMessageDialog(null, "Orignal File Deletion Failed", 
                                                  "Proper Deletion Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                // Inform User that Target Data is Not Found
                JOptionPane.showMessageDialog(null, "Member Data is Not Found!", 
                                              "Data Not Found", JOptionPane.ERROR_MESSAGE);
                // Delete Temporary File since Target Data is not found
                tempFile.delete();
            }
                        
        } catch (IOException e) { //Catch Any Error then Inform User About It
            JOptionPane.showMessageDialog(null, "An Error Occurred While Deleting the Member's Data: "+e,
                                          "Deletion Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }
    
    private void loadMembersDetails(){
        // LOAD MEMBERS DETAILS IN TABLE
        DefaultTableModel model = (DefaultTableModel) membersDetailsTable.getModel();
        model.setRowCount(0);
        
        try (BufferedReader bReader = new BufferedReader(new FileReader("membersDetails.txt"))){
            String line;
            while ((line = bReader.readLine()) != null){  //Read each line
                String[] bookDetails = line.split(","); // Split the CSV
                model.addRow(new Object[]{bookDetails[0].trim(), bookDetails[1].trim(),
                                          bookDetails[2].trim(), bookDetails[3].trim()}); //Add data to new row in the table   
            }
            
        } catch (IOException e){ //Catch any Error, then show that it occured to user
            JOptionPane.showMessageDialog(null, "Error Loading Member Details: "+e,
                                          "Loading Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void sortMembersDetailsTable(){
        //SORT MEMBERS DETAILS IN TABLE
        // Create TableRowSorter for the Table's Model
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(membersDetailsTable.getModel());
        membersDetailsTable.setRowSorter(sorter); // Set sorter for the table
        
        //Allow Sorting of Column 0,2,3
        sorter.setSortable(0, true);
        sorter.setSortable(2, true);
        sorter.setSortable(3, true);
        //Inhibit Sorting at Column 1
        sorter.setSortable(1, false);
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageMembersPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageMembersPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageMembersPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageMembersPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageMembersPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JButton backButton;
    private javax.swing.JLabel branchLabel;
    private javax.swing.JTextField branchTextField;
    private javax.swing.JComboBox<String> courseComboBox;
    private javax.swing.JLabel courseLabel;
    private javax.swing.JButton deleteButton;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel mainManageMembersPanel;
    private javax.swing.JPanel manageMembersPanel;
    private javax.swing.JLabel manageMembersTitleLabel;
    private javax.swing.JLabel memberIDLabel;
    private javax.swing.JTextField memberIDTextField;
    private javax.swing.JLabel memberNameLabel;
    private javax.swing.JTextField memberNameTextField;
    private javax.swing.JTable membersDetailsTable;
    private javax.swing.JLabel tipLabel;
    // End of variables declaration//GEN-END:variables
}
