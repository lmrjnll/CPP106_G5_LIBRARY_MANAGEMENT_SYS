// MANAGE BOOKS PAGE

package com.mycompany.library_management_system;

// Import all necessary class for functionalities
import java.util.List;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class ManageBooksPage extends javax.swing.JFrame {

    public ManageBooksPage() {
        initComponents(); //Initialize then add all Components to Frame
                
        loadBooksDetails(); // Load Books Details For Its Table
        sortBooksDetailsTable(); // Sort Table by ID in Ascending Order
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        addQuantityDialog = new javax.swing.JDialog();
        bookIDLabelAQD = new javax.swing.JLabel();
        bookIDTextFieldAQD = new javax.swing.JTextField();
        addedBookQuantityLabelAQD = new javax.swing.JLabel();
        addedBookQuantityTextFieldAQD = new javax.swing.JTextField();
        cancelButtonAQD = new javax.swing.JButton();
        addButtonAQD = new javax.swing.JButton();
        addBookQuantityTitleLabelAQD = new javax.swing.JLabel();
        manageBooksPanel = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        bookIDLabel = new javax.swing.JLabel();
        bookIDTextField = new javax.swing.JTextField();
        bookTitleLabel = new javax.swing.JLabel();
        bookTitleTextField = new javax.swing.JTextField();
        authorsNameLabel = new javax.swing.JLabel();
        bookAuthorTextField = new javax.swing.JTextField();
        quantityLabel = new javax.swing.JLabel();
        bookQuantitySpinner = new javax.swing.JSpinner();
        addButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        addBookQuantityButton = new javax.swing.JButton();
        mainManageBooksPanel = new javax.swing.JPanel();
        manageBooksTitleLabel = new javax.swing.JLabel();
        booksDetailsTableScrollPane = new javax.swing.JScrollPane();
        booksDetailsTable = new javax.swing.JTable();
        tipLabel = new javax.swing.JLabel();

        addQuantityDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addQuantityDialog.setAlwaysOnTop(true);

        bookIDLabelAQD.setText("Enter Book ID:");

        addedBookQuantityLabelAQD.setText("Enter Quantity to be Added:");

        cancelButtonAQD.setText("CANCEL");
        cancelButtonAQD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonAQDActionPerformed(evt);
            }
        });

        addButtonAQD.setText("ADD");
        addButtonAQD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonAQDActionPerformed(evt);
            }
        });

        addBookQuantityTitleLabelAQD.setText("ADD BOOK QUANTITY");

        javax.swing.GroupLayout addQuantityDialogLayout = new javax.swing.GroupLayout(addQuantityDialog.getContentPane());
        addQuantityDialog.getContentPane().setLayout(addQuantityDialogLayout);
        addQuantityDialogLayout.setHorizontalGroup(
            addQuantityDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addQuantityDialogLayout.createSequentialGroup()
                .addGroup(addQuantityDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addQuantityDialogLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(addQuantityDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bookIDLabelAQD)
                            .addComponent(bookIDTextFieldAQD)
                            .addComponent(addedBookQuantityLabelAQD)
                            .addComponent(addedBookQuantityTextFieldAQD, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(addQuantityDialogLayout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(addBookQuantityTitleLabelAQD))
                    .addGroup(addQuantityDialogLayout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(cancelButtonAQD)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addButtonAQD)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        addQuantityDialogLayout.setVerticalGroup(
            addQuantityDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addQuantityDialogLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(addBookQuantityTitleLabelAQD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bookIDLabelAQD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookIDTextFieldAQD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addedBookQuantityLabelAQD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(addedBookQuantityTextFieldAQD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(addQuantityDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelButtonAQD)
                    .addComponent(addButtonAQD))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        manageBooksPanel.setBackground(new java.awt.Color(0, 0, 204));

        backButton.setText("Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        bookIDLabel.setForeground(new java.awt.Color(255, 255, 255));
        bookIDLabel.setText("Enter Book ID:");

        bookTitleLabel.setBackground(new java.awt.Color(255, 255, 255));
        bookTitleLabel.setForeground(new java.awt.Color(255, 255, 255));
        bookTitleLabel.setText("Enter Book Title:");

        authorsNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        authorsNameLabel.setText("Enter Author's Name:");

        quantityLabel.setForeground(new java.awt.Color(255, 255, 255));
        quantityLabel.setText("Enter Quantity:");

        bookQuantitySpinner.setModel(new javax.swing.SpinnerNumberModel(1, 1, 30, 1));

        addButton.setText("ADD");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("DELETE");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        addBookQuantityButton.setText("ADD BOOK QUANTITY");
        addBookQuantityButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBookQuantityButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout manageBooksPanelLayout = new javax.swing.GroupLayout(manageBooksPanel);
        manageBooksPanel.setLayout(manageBooksPanelLayout);
        manageBooksPanelLayout.setHorizontalGroup(
            manageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manageBooksPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(manageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bookIDTextField)
                    .addComponent(bookTitleTextField)
                    .addComponent(bookAuthorTextField)
                    .addComponent(bookQuantitySpinner)
                    .addGroup(manageBooksPanelLayout.createSequentialGroup()
                        .addGroup(manageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bookIDLabel)
                            .addComponent(bookTitleLabel)
                            .addComponent(authorsNameLabel)
                            .addComponent(quantityLabel))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(manageBooksPanelLayout.createSequentialGroup()
                .addGroup(manageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(addBookQuantityButton)
                    .addGroup(manageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(manageBooksPanelLayout.createSequentialGroup()
                            .addGap(45, 45, 45)
                            .addComponent(addButton)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(deleteButton))))
                .addGap(0, 42, Short.MAX_VALUE))
        );
        manageBooksPanelLayout.setVerticalGroup(
            manageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manageBooksPanelLayout.createSequentialGroup()
                .addComponent(backButton)
                .addGap(57, 57, 57)
                .addComponent(bookIDLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bookTitleLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookTitleTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(authorsNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookAuthorTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quantityLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookQuantitySpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(manageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addButton)
                    .addComponent(deleteButton))
                .addGap(18, 18, 18)
                .addComponent(addBookQuantityButton)
                .addGap(111, 111, 111))
        );

        manageBooksTitleLabel.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        manageBooksTitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        manageBooksTitleLabel.setText("Manage Books");

        booksDetailsTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        booksDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Title", "Author", "Quantity"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        booksDetailsTable.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        booksDetailsTable.setShowGrid(false);
        booksDetailsTable.getTableHeader().setResizingAllowed(false);
        booksDetailsTable.getTableHeader().setReorderingAllowed(false);
        booksDetailsTableScrollPane.setViewportView(booksDetailsTable);
        if (booksDetailsTable.getColumnModel().getColumnCount() > 0) {
            booksDetailsTable.getColumnModel().getColumn(0).setResizable(false);
            booksDetailsTable.getColumnModel().getColumn(1).setResizable(false);
            booksDetailsTable.getColumnModel().getColumn(2).setResizable(false);
            booksDetailsTable.getColumnModel().getColumn(3).setResizable(false);
        }

        tipLabel.setText("Tip: Press Table Header to Sort Column");

        javax.swing.GroupLayout mainManageBooksPanelLayout = new javax.swing.GroupLayout(mainManageBooksPanel);
        mainManageBooksPanel.setLayout(mainManageBooksPanelLayout);
        mainManageBooksPanelLayout.setHorizontalGroup(
            mainManageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainManageBooksPanelLayout.createSequentialGroup()
                .addGroup(mainManageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(booksDetailsTableScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 586, Short.MAX_VALUE)
                    .addGroup(mainManageBooksPanelLayout.createSequentialGroup()
                        .addGroup(mainManageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainManageBooksPanelLayout.createSequentialGroup()
                                .addGap(209, 209, 209)
                                .addComponent(manageBooksTitleLabel))
                            .addGroup(mainManageBooksPanelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(tipLabel)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        mainManageBooksPanelLayout.setVerticalGroup(
            mainManageBooksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainManageBooksPanelLayout.createSequentialGroup()
                .addComponent(manageBooksTitleLabel)
                .addGap(48, 48, 48)
                .addComponent(booksDetailsTableScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tipLabel)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(manageBooksPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mainManageBooksPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(manageBooksPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(mainManageBooksPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        //REDIRECT TO MAIN PAGE
        MainPage mainPage = new MainPage();
        mainPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // ADD BOOK TO TABLE AND FILE
        DefaultTableModel model = (DefaultTableModel) booksDetailsTable.getModel(); // Get Table Model
        
        // Get Book Details
        String bookID = bookIDTextField.getText();
        String bookTitle = bookTitleTextField.getText();
        String bookAuthor = bookAuthorTextField.getText();
        String bookQuantity = Integer.toString((Integer) bookQuantitySpinner.getValue());
        
        // Convert to List for Easy Traversal
        List bookDetailsValues = Arrays.asList(bookID, bookTitle, bookAuthor, bookQuantity);
        
        if (!anyEmpty(bookDetailsValues)) { //Check if any of the fields are not empty
            
            if (saveBookDetails(bookDetailsValues)){ //Save Book Details to File
                model.addRow(new Object []{bookID, bookTitle, bookAuthor, bookQuantity}); //Add Book Details to Table if Success
            }
    
        } else { //Urge User to Fill All The Required Fields           
            JOptionPane.showMessageDialog(null, "Fill All Required Fields!", "Input Error", JOptionPane.ERROR_MESSAGE);           
        }
    }//GEN-LAST:event_addButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        //REMOVE BOOK IN TABLE AND FILE
        DefaultTableModel model = (DefaultTableModel) booksDetailsTable.getModel(); //Get Table Model
        
        if (booksDetailsTable.getSelectedRow() != -1){ //Check if Any Row is Currently Selected    
            
            //Show Sorting Warning
            JOptionPane.showMessageDialog(null, "Sorting Table Might Cause Deletion Error\nIf You Have Sorted Table, Please Press Back To Reset Table",
                                          "Sort Warning", JOptionPane.WARNING_MESSAGE);
            //Ask for Deletion Confirmaation
            int input = JOptionPane.showConfirmDialog(null, "Delete Book's Data?", 
                                                      "Deletion Confirmation", JOptionPane.YES_NO_CANCEL_OPTION);
            
            if (input==0){ //Check if User Confirmed, (0 = Yes , 1 = No , 2 = Cancel)
                if (deleteBookDetails(booksDetailsTable.getSelectedRow())){ //Delete Book in File
                    model.removeRow(booksDetailsTable.getSelectedRow()); //Remove Book in Table     
                }             
            }
            
        } else { // Inform User that they need to select a book before deleting            
            JOptionPane.showMessageDialog(null, "Please Select A Book To Be Deleted", "Select Book", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void addBookQuantityButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBookQuantityButtonActionPerformed
        // SHOW ADD BOOK QUANTITY DIALOG
        // ADD BOOK QUANTITY THEN UPDATE RECORDS
        addQuantityDialog.setVisible(true);
        addQuantityDialog.setSize(332,262);
    }//GEN-LAST:event_addBookQuantityButtonActionPerformed

    private void cancelButtonAQDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonAQDActionPerformed
        //EXIT DIALOG
        bookIDTextFieldAQD.setText("");
        addedBookQuantityTextFieldAQD.setText("");
        addQuantityDialog.dispose();
    }//GEN-LAST:event_cancelButtonAQDActionPerformed

    private void addButtonAQDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonAQDActionPerformed
        // ADD BOOK QUANTITY
        //Get bookID and addedQuantity, then initialize totalQuantity
        String bookID = bookIDTextFieldAQD.getText();
        String addedQuantity = addedBookQuantityTextFieldAQD.getText();
        String totalQuantity;
        
        if (anyEmpty(Arrays.asList(bookID, addedQuantity))){ //Check if any of the inputs is Empty
            JOptionPane.showMessageDialog(null, "Fill All Required Fields",
                                          "Input Error", JOptionPane.ERROR_MESSAGE); //Inform user of Input Error
            return; //Early Return Since there is Input Error
        }
        
        //Initialize origFile and tempFile
        File origFile = new File("booksDetails.txt");
        File tempFile = new File("tempBooksDetails.txt"); 
        try (BufferedReader bReader = new BufferedReader(new FileReader(origFile));//Use Reader and Writer to Update File Records
             BufferedWriter bWriter = new BufferedWriter(new FileWriter(tempFile))){ 
            String line;
            while((line = bReader.readLine()) != null){ //Read Each Line
                String[] lineDetails = line.split(","); //Split Line
                
                if (lineDetails[0].equals(bookID)){ //Check if Recorded BookI ID is same as input
                    //Add the Previous and Added Quantity to get Total
                    totalQuantity = Integer.toString(Integer.parseInt(lineDetails[3]) + Integer.parseInt(addedQuantity));
                    lineDetails[3] = totalQuantity; //Update the Quantity value
                    
                    bWriter.write(String.join(",", lineDetails)); //Write updated line to file
                    bWriter.newLine(); //Add new line
                    continue; //Continue to next loop since current one is already written
                }
                
                //Write current line and add new line
                bWriter.write(line);
                bWriter.newLine();    
            }
            
            //Close Reader and Writer to Allow File Deletion and Renaming
            bReader.close();
            bWriter.close();
            
            if (origFile.delete()){ //Check if original file can be deleted
                tempFile.renameTo(origFile); //rename tempFile same as origFile
                JOptionPane.showMessageDialog(null, "Added Quantity Successful",
                                              "Saving Success", JOptionPane.INFORMATION_MESSAGE); //Inform User of Saving Success
                loadBooksDetails(); //Update Table
            } else { //Inform user of Error Adding
                JOptionPane.showMessageDialog(null, "Error Adding Quantity",
                                              "Saving Failed", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (IOException e) { //Inform user of any Errors
            JOptionPane.showMessageDialog(null, "Error Saving Total Quantity: "+e,
                                          "Saving Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_addButtonAQDActionPerformed
    
    private static boolean anyEmpty(List<String> strings){
        //CHECK IF ANY OF THE ELEMENTS IN THE LIST IS EMPTY OR NULL       
        boolean hasEmpty = strings.stream() //List is Used for Easier Traversal and Checking
                                  .anyMatch(str -> str == null || str.trim().isEmpty()); //Checks if any of the values are null/empty
        
        return hasEmpty; //Returns True if Empty, False if Not Empty
    }
    
    private String[] getRowData(int selectedRow){
        //CONVERTS DATA IN ROW TO A CSV FORMATTED DATA
        DefaultTableModel model = (DefaultTableModel) booksDetailsTable.getModel(); //Get Table Model

        int[] columns = {0,1,2,3}; //No. of Fixed Columns
        String[] values = new String[columns.length]; //Makes a List of Values in Each Column in a Specific Row
        
        for (int i = 0; i < columns.length; i++){ //Iterate through each column
            values[i] = model.getValueAt(selectedRow, columns[i]).toString().trim(); //Obtain Value at the Target Cell (Row and Column)
        }
        
        return values; //Return values
    }
    
    private static boolean saveBookDetails(List<String> bookDetails){
        //SAVE BOOK DETAILS IN FILE
        
        //Get bookID from bookDetails List
        String bookID = bookDetails.get(0);
        
        File bookDetailsTxt = new File("booksDetails.txt"); //Initialize book details file
        boolean duplicate = false; //Track if bookID is already in use
        try (BufferedReader bReader = new BufferedReader(new FileReader(bookDetailsTxt))){ //Check for Duplicate Book IDs
            
            String line;
            while((line = bReader.readLine()) != null){
                String[] lineDetails = line.split(","); //Split current line
                
                //Check if bookID in line is same as user input
                if (lineDetails[0].equals(bookID)){  
                    //Inform user that Book ID is Already in Use
                    JOptionPane.showMessageDialog(null, "Book ID is Already In Use\nPlease Select Another",
                                                  "ID Duplication Warning", JOptionPane.WARNING_MESSAGE);
                    duplicate = true;
                    break; //Break loop since it is already found    
                }
                
            }
           
        } catch (IOException e){ //Inform User about Errors in Saving
            JOptionPane.showMessageDialog(null, "Error Reading Book Details: "+e,
                                          "Reading Error", JOptionPane.ERROR_MESSAGE);
            return false; //Early Return Since there is Reading Error
        }
             
        if (!duplicate){ //If there is no duplicate then...
            
            try (BufferedWriter bWriter = new BufferedWriter(new FileWriter(bookDetailsTxt, true))){               
                bWriter.write(String.join(",", bookDetails)); //Save Book Details in CSV Format in File 
                bWriter.newLine(); //Add New Line
                JOptionPane.showMessageDialog(null, "Book data saved successfully.",
                                              "Saved Successfully", JOptionPane.INFORMATION_MESSAGE); //Inform user About Saving Success
                return true; //Return true since it is Saved Successfully
                
            } catch (IOException e) { //Inform User of Any Errors
                JOptionPane.showMessageDialog(null, "Error Saving Book Details: "+e,
                                              "Saving Error", JOptionPane.ERROR_MESSAGE);
                return false; //Return False Since there is Saving Error
            } 
        }
        
        return false; //Return False since there is duplicate
    }
    
    private boolean deleteBookDetails(int selectedRow){
        //DELETES BOOK DETAILS IN FILE
        //Since Direct Deletion in File is not Possible we will...
        //Read Each Line in OrigFile, Write Each Line in TempFile
        //If Current Line Contains the Data to be Deleted Then Don't Write Current Line
        //Delete OrigFile then Rename TempFile to OrigFile if Found
        //Else Delete TempFile
        String[] rowData = getRowData(selectedRow); //Obtains the Selected Row in the Table
        
        //Initialize the Orignal and Temporary File
        File originalFile = new File("booksDetails.txt");
        File tempFile = new File("tempBooksDetails.txt");
        
        try (BufferedReader bReader = new BufferedReader(new FileReader(originalFile)); //Read Each Line in Original File
             BufferedWriter bWriter = new BufferedWriter(new FileWriter(tempFile))){ //Write Each Line in Temporary File
            
            String line; //Initialize Line
            boolean found = false; //Tracks if the target data is found or not 
            while ((line = bReader.readLine()) != null){ //Read Line and Loop Till the End of File
                String[] details = line.split(",");
                
                if (details[0].equals(rowData[0])){ //Checks if the line is the same as the CSV Formatted one
                    found = true; //If found then skip this line and continue to the next
                    
                } else {
                    bWriter.write(line); //If not found then writes the current line in the Temporary File
                    bWriter.newLine();   
                }    
            }
            
            // Close BufferedReader and BufferedWriter to avoid errors in deletion and renaming
            bReader.close();
            bWriter.close();
            
            if(found){ //Checks if Target Data is Found
                
                if(originalFile.delete()){ //Checks if Orignal File can be deleted, if it can, proceeds to delete it
                    tempFile.renameTo(originalFile); //Rename Temporary File the same as the Original File
                    //Inform User that Deletion is a Success
                    JOptionPane.showMessageDialog(null, "Book Data Deleted Successfully!",
                                                  "Deletion Success", JOptionPane.INFORMATION_MESSAGE);
                    return true;
                    
                } else {
                    // Inform User that Error Occured in Proper Deletion
                    JOptionPane.showMessageDialog(null, "Orignal File Deletion Failed", 
                                                  "Proper Deletion Error", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                
            } else {
                // Inform User that Target Data is Not Found
                JOptionPane.showMessageDialog(null, "Book Data is Not Found!", 
                                              "Data Not Found", JOptionPane.ERROR_MESSAGE);
                // Delete Temporary File since Target Data is not found
                tempFile.delete();
                return false;
            }
                        
        } catch (IOException e) { //Catch Any Error then Inform User About It
            JOptionPane.showMessageDialog(null, "An Error Occurred While Deleting the Book's Data: "+e,
                                          "Deletion Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
    }
    
    private void loadBooksDetails(){
        //LOADS PRESAVED DATA TO TABLE
        DefaultTableModel model = (DefaultTableModel) booksDetailsTable.getModel(); //Get Table Model
        model.setRowCount(0); //Reset Row Count

        try (BufferedReader bReader = new BufferedReader(new FileReader("booksDetails.txt"))){ //Read File
            
            String line;
            while ((line = bReader.readLine()) != null){ //Read Each Line then convert it to Array
                String[] bookDetails = line.split(","); //Split data in current line
                //Add Each Line To a New Row in the Table
                model.addRow(new Object[]{bookDetails[0].trim(), bookDetails[1].trim(),
                                          bookDetails[2].trim(), bookDetails[3].trim()});     
            }
            
        } catch (IOException e){ //Catch Any Error then Inform User About It
            JOptionPane.showMessageDialog(null, "Error Loading Book Details: "+e,
                                          "Loading Error", JOptionPane.ERROR_MESSAGE);
        }    
    }
    
    private void sortBooksDetailsTable(){
        //SORT BOOKS DETAILS TABLE
        // Create TableRowSorter for the Table's Model
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(booksDetailsTable.getModel());
        booksDetailsTable.setRowSorter(sorter); // Set sorter for the table
        
        //Allow sorting at Column 0
        sorter.setSortable(0,true); 
        //Inhibit Sorting at Column 1 and 2
        sorter.setSortable(1, false);
        sorter.setSortable(2, false);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageBooksPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBookQuantityButton;
    private javax.swing.JLabel addBookQuantityTitleLabelAQD;
    private javax.swing.JButton addButton;
    private javax.swing.JButton addButtonAQD;
    private javax.swing.JDialog addQuantityDialog;
    private javax.swing.JLabel addedBookQuantityLabelAQD;
    private javax.swing.JTextField addedBookQuantityTextFieldAQD;
    private javax.swing.JLabel authorsNameLabel;
    private javax.swing.JButton backButton;
    private javax.swing.JTextField bookAuthorTextField;
    private javax.swing.JLabel bookIDLabel;
    private javax.swing.JLabel bookIDLabelAQD;
    private javax.swing.JTextField bookIDTextField;
    private javax.swing.JTextField bookIDTextFieldAQD;
    private javax.swing.JSpinner bookQuantitySpinner;
    private javax.swing.JLabel bookTitleLabel;
    private javax.swing.JTextField bookTitleTextField;
    private javax.swing.JTable booksDetailsTable;
    private javax.swing.JScrollPane booksDetailsTableScrollPane;
    private javax.swing.JButton cancelButtonAQD;
    private javax.swing.JButton deleteButton;
    private javax.swing.JPanel mainManageBooksPanel;
    private javax.swing.JPanel manageBooksPanel;
    private javax.swing.JLabel manageBooksTitleLabel;
    private javax.swing.JLabel quantityLabel;
    private javax.swing.JLabel tipLabel;
    // End of variables declaration//GEN-END:variables
}
