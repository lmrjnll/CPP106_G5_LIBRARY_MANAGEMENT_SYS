//ISSUE BOOKS PAGE

package com.mycompany.library_management_system;

//Import All Necessary Classes For Functionalities
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.*;

public class IssueBooksPage extends javax.swing.JFrame {

    public IssueBooksPage() {
        initComponents(); //Initialize then add all Components to Frame
        
        //Format IssueDate/DueDate Spinner
        configureIssueDateSpinner();
        configureDueDateSpinner();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        issueBooksNavigationPanel = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        bookIDLabel = new javax.swing.JLabel();
        bookIDTextField = new javax.swing.JTextField();
        memberIDLabel = new javax.swing.JLabel();
        memberIDTextField = new javax.swing.JTextField();
        issueDateLabel = new javax.swing.JLabel();
        issueDateSpinner = new javax.swing.JSpinner();
        dueDateLabel = new javax.swing.JLabel();
        dueDateSpinner = new javax.swing.JSpinner();
        issueBookButton = new javax.swing.JButton();
        findButton = new javax.swing.JButton();
        issueBooksTitleLabel = new javax.swing.JLabel();
        bookDetailsPanel = new javax.swing.JPanel();
        bookDetailsTitleLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        bookDetailsTextArea = new javax.swing.JTextArea();
        memberDetailsPanel = new javax.swing.JPanel();
        memberDetailsTitleLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        memberDetailsTextArea = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        issueBooksNavigationPanel.setBackground(new java.awt.Color(0, 0, 204));

        backButton.setText("Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        bookIDLabel.setForeground(new java.awt.Color(255, 255, 255));
        bookIDLabel.setText("Enter Book ID:");

        memberIDLabel.setForeground(new java.awt.Color(255, 255, 255));
        memberIDLabel.setText("Enter Member ID:");

        issueDateLabel.setForeground(new java.awt.Color(255, 255, 255));
        issueDateLabel.setText("Issue Date:");

        issueDateSpinner.setModel(new javax.swing.SpinnerDateModel());

        dueDateLabel.setBackground(new java.awt.Color(255, 255, 255));
        dueDateLabel.setForeground(new java.awt.Color(255, 255, 255));
        dueDateLabel.setText("Due Date:");

        dueDateSpinner.setModel(new javax.swing.SpinnerDateModel());

        issueBookButton.setText("ISSUE BOOK");
        issueBookButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        issueBookButton.setEnabled(false);
        issueBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                issueBookButtonActionPerformed(evt);
            }
        });

        findButton.setText("FIND DETAILS");
        findButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findButtonActionPerformed(evt);
            }
        });

        issueBooksTitleLabel.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        issueBooksTitleLabel.setForeground(new java.awt.Color(255, 255, 255));
        issueBooksTitleLabel.setText("Issue Books");

        javax.swing.GroupLayout issueBooksNavigationPanelLayout = new javax.swing.GroupLayout(issueBooksNavigationPanel);
        issueBooksNavigationPanel.setLayout(issueBooksNavigationPanelLayout);
        issueBooksNavigationPanelLayout.setHorizontalGroup(
            issueBooksNavigationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(issueBooksNavigationPanelLayout.createSequentialGroup()
                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(issueBooksNavigationPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(issueBooksNavigationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(issueBookButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bookIDTextField)
                    .addComponent(memberIDTextField)
                    .addComponent(issueDateSpinner)
                    .addComponent(dueDateSpinner)
                    .addComponent(findButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(issueBooksNavigationPanelLayout.createSequentialGroup()
                        .addGroup(issueBooksNavigationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bookIDLabel)
                            .addComponent(memberIDLabel)
                            .addComponent(issueDateLabel)
                            .addComponent(dueDateLabel)
                            .addComponent(issueBooksTitleLabel))
                        .addGap(0, 46, Short.MAX_VALUE)))
                .addContainerGap())
        );
        issueBooksNavigationPanelLayout.setVerticalGroup(
            issueBooksNavigationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(issueBooksNavigationPanelLayout.createSequentialGroup()
                .addComponent(backButton)
                .addGap(18, 18, 18)
                .addComponent(issueBooksTitleLabel)
                .addGap(40, 40, 40)
                .addComponent(bookIDLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(memberIDLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(memberIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(issueDateLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(issueDateSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dueDateLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dueDateSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(findButton)
                .addGap(18, 18, 18)
                .addComponent(issueBookButton)
                .addGap(0, 99, Short.MAX_VALUE))
        );

        bookDetailsPanel.setBackground(new java.awt.Color(255, 0, 0));

        bookDetailsTitleLabel.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        bookDetailsTitleLabel.setForeground(new java.awt.Color(255, 255, 255));
        bookDetailsTitleLabel.setText("Book Details");

        jScrollPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        bookDetailsTextArea.setEditable(false);
        bookDetailsTextArea.setColumns(30);
        bookDetailsTextArea.setLineWrap(true);
        bookDetailsTextArea.setRows(12);
        bookDetailsTextArea.setText("Book ID:\n\n\nBook Title:\n\n\nAuthor:\n\n\nQuantity:\n\n");
        bookDetailsTextArea.setWrapStyleWord(true);
        jScrollPane1.setViewportView(bookDetailsTextArea);

        javax.swing.GroupLayout bookDetailsPanelLayout = new javax.swing.GroupLayout(bookDetailsPanel);
        bookDetailsPanel.setLayout(bookDetailsPanelLayout);
        bookDetailsPanelLayout.setHorizontalGroup(
            bookDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bookDetailsPanelLayout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addComponent(bookDetailsTitleLabel)
                .addContainerGap(82, Short.MAX_VALUE))
            .addGroup(bookDetailsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        bookDetailsPanelLayout.setVerticalGroup(
            bookDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bookDetailsPanelLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(bookDetailsTitleLabel)
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        memberDetailsPanel.setBackground(new java.awt.Color(0, 255, 0));

        memberDetailsTitleLabel.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        memberDetailsTitleLabel.setForeground(new java.awt.Color(255, 255, 255));
        memberDetailsTitleLabel.setText("Member Details");

        jScrollPane2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        memberDetailsTextArea.setEditable(false);
        memberDetailsTextArea.setColumns(20);
        memberDetailsTextArea.setRows(5);
        memberDetailsTextArea.setText("Member ID:\n\n\nMember Name:\n\n\nCourse:\n\n\nBranch:\n\n");
        jScrollPane2.setViewportView(memberDetailsTextArea);

        javax.swing.GroupLayout memberDetailsPanelLayout = new javax.swing.GroupLayout(memberDetailsPanel);
        memberDetailsPanel.setLayout(memberDetailsPanelLayout);
        memberDetailsPanelLayout.setHorizontalGroup(
            memberDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(memberDetailsPanelLayout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(memberDetailsTitleLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(memberDetailsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)
                .addContainerGap())
        );
        memberDetailsPanelLayout.setVerticalGroup(
            memberDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(memberDetailsPanelLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(memberDetailsTitleLabel)
                .addGap(30, 30, 30)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(issueBooksNavigationPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(bookDetailsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(memberDetailsPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(issueBooksNavigationPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(bookDetailsPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(memberDetailsPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        //REDIRECT TO MAIN PAGE
        MainPage mainPage = new MainPage();
        mainPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    private void findButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findButtonActionPerformed
        //FIND BOOK AND MEMBER DETAILS
        //Get Book/Member ID
        String bookID = bookIDTextField.getText();
        String memberID = memberIDTextField.getText();
        
        if (!anyEmpty(Arrays.asList(bookID, memberID))){ //Check if any of Book/Member ID Input is not Empty
            String[] bookDetails = findBookDetails(bookID); //Obtain Book Details Through Book ID
            String[] memberDetails = findMemberDetails(memberID); //Obtain Member Details Through Member ID
            
            //Check if BookDetails/MemberDetails is Not Null and Length = 4
            if (bookDetails != null && bookDetails.length == 4 && memberDetails != null && memberDetails.length == 4){
                //Inform User that Book/Member Details is Found
                JOptionPane.showMessageDialog(null, "Book Details Found",
                                              "Search Success", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(null, "Member Details Found",
                                              "Search Success", JOptionPane.INFORMATION_MESSAGE);
                
                //Format the Text for Book/Member Details for Easy Set in Label
                String formattedBookDetailsText = String.format("Book ID:%n%s%n%nBook Title:%n%s%n%nAuthor:%n%s%n%nQuantity:%n%s%n", 
                                                     bookDetails[0], bookDetails[1], bookDetails[2], bookDetails[3]);
                String formattedMemberDetailsText = String.format("Member ID:%n%s%n%nMember Name:%n%s%n%nCourse:%n%s%n%nBranch:%n%s%n", 
                                                     memberDetails[0], memberDetails[1], memberDetails[2], memberDetails[3]);
                
                //Set Label Text using the Formatted Book/Member Details
                bookDetailsTextArea.setText(formattedBookDetailsText);
                memberDetailsTextArea.setText(formattedMemberDetailsText);
                
                //Enable Issue Book Button Since Necessary Details are Found
                issueBookButton.setEnabled(true);
            }
            
        } else { //Inform user of Input Error
            JOptionPane.showMessageDialog(null, "Fill All Required Fields!", "Input Error", JOptionPane.ERROR_MESSAGE);
        }        
    }//GEN-LAST:event_findButtonActionPerformed

    private void issueBookButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_issueBookButtonActionPerformed
        //ISSUE BOOK TO MEMBER
        //Get TextField Inputs
        String bookID = bookIDTextField.getText();
        String memberID = memberIDTextField.getText();
        String issueDate = new SimpleDateFormat("dd-MM-yyyy").format(issueDateSpinner.getValue()); //Format Both Issue and Due Date
        String dueDate = new SimpleDateFormat("dd-MM-yyyy").format(dueDateSpinner.getValue());
        
        if (!anyEmpty(Arrays.asList(bookID, memberID))){ //Check if Any of the Book/Member ID is Not Empty
            String [] bookDetails = findBookDetails(bookID); //Obtain Book Details Through Book ID
            String [] memberDetails = findMemberDetails(memberID); //Obtain Member Details Through Member ID
            
            //Check if BookDetails/MemberDetails is Not Null and Length = 4
            if (bookDetails != null && bookDetails.length == 4 && memberDetails != null && memberDetails.length == 4){
                saveIssuedBookDetails(bookDetails, memberDetails, issueDate, dueDate); //Save Issued Book Records in File
            }
        }
    }//GEN-LAST:event_issueBookButtonActionPerformed
    
    private void configureIssueDateSpinner() {
        //FORMATS AND CONFIGURES THE ISSUE DATE SPINNER
        //Get Currrent Date
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        
        //Subtract 2 Days to Current Date For MinDate
        calendar.add(Calendar.DAY_OF_MONTH, -2);
        Date minDate = calendar.getTime();
        
        //Set the initial/min/max dates as well as the step size of spinner
        SpinnerDateModel issueDateModel = new SpinnerDateModel(currentDate, minDate, currentDate, Calendar.DAY_OF_MONTH);
        issueDateSpinner.setModel(issueDateModel);
        
        //Format the Date in Spinner
        JSpinner.DateEditor issueDateEditor = new JSpinner.DateEditor(issueDateSpinner, "dd-MM-yyyy");
        issueDateSpinner.setEditor(issueDateEditor);  
    }

    private void configureDueDateSpinner() {
        //FORMATS AND CONFIGURES THE DUE DATE SPINNER
        //Get Currrent Date
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        
        //Subtract 1 Days to Current Date For MinDate
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        Date minDate = calendar.getTime();
        
        //Add 15 Days to Current Date For MaxDate
        calendar.add(Calendar.DAY_OF_MONTH, 15);
        Date maxDate = calendar.getTime();
        
        //Set the initial/min/max dates as well as the step size of spinner
        SpinnerDateModel dueDateModel = new SpinnerDateModel(currentDate, minDate, maxDate, Calendar.DAY_OF_MONTH);
        dueDateSpinner.setModel(dueDateModel);
        
        //Format the Date in Spinner
        JSpinner.DateEditor dueDateEditor = new JSpinner.DateEditor(dueDateSpinner, "dd-MM-yyyy");
        dueDateSpinner.setEditor(dueDateEditor);  
    }

    private static boolean anyEmpty(List<String> strings){
        boolean hasEmpty = strings.stream() //List is Used for Easier Traversal and Checking
                                  .anyMatch(str -> str == null || str.trim().isEmpty()); //Checks if any of the values are null/empty
        
        return hasEmpty; //Returns True if Empty, False if Not Empty
    }
    
    private static String[] findBookDetails(String bookID){
        //FINDS BOOK DETAILS
        String [] foundBookDetails; //Initialize Book Details being searched
        try (BufferedReader bReader = new BufferedReader(new FileReader("booksDetails.txt"))){
            String line;
            while((line = bReader.readLine()) != null){
                String [] lineByLineBookDetails = line.split(",");
                
                    if(lineByLineBookDetails[0].equals(bookID)){ //Check if Recorded Book ID is same as Input
                        foundBookDetails = lineByLineBookDetails; //Declare foundBookDetails as current line details
                        return foundBookDetails; //Return foundBookDetails since search is finished
                    }
            } 
        } catch (IOException e){
                JOptionPane.showMessageDialog(null, "Book Details Not Found: "+e,
                                              "Search Failed", JOptionPane.ERROR_MESSAGE);
                return null; //Return Since There is Search Failure
        }
        JOptionPane.showMessageDialog(null, "Book Details Not Found",
                                      "Search Failed", JOptionPane.ERROR_MESSAGE);
        return null; //Return Null Since There are No Records that Match
    }

    private static String[] findMemberDetails(String memberID){
        //FINDS MEMBER DETAILS
        String [] foundMemberDetails; //Initialize Member Details being searched
        try (BufferedReader bReader = new BufferedReader(new FileReader("membersDetails.txt"))){
            String line;
            while((line = bReader.readLine()) != null){
                String [] lineByLineMemberDetails = line.split(",");
                
                    if(lineByLineMemberDetails[0].equals(memberID)){ //Check if Recorded Member ID is same as Input
                        foundMemberDetails = lineByLineMemberDetails; //Declare foundMemberDetails as current line details
                        return foundMemberDetails; //Return foundMemberDetails since search is finished
                    }
            }
        } catch (IOException e){
                JOptionPane.showMessageDialog(null, "Member Details Not Found: "+e,
                                              "Search Failed", JOptionPane.ERROR_MESSAGE);
                return null; //Return Since There is Search Failure
        }
        JOptionPane.showMessageDialog(null, "Member Details Not Found",
                                      "Search Failed", JOptionPane.ERROR_MESSAGE);
        return null; //Return Null Since There are No Records that Match
        
    }
    
    private void saveIssuedBookDetails(String[] bookDetails, String[] memberDetails, String issueDate, String dueDate){
        //SAVES ISSUED BOOK DETAILS TO FILE
        String[] issueBooksDetails = {memberDetails[1], memberDetails[0], memberDetails[2], bookDetails[1],
                                       bookDetails[0], issueDate, dueDate, null}; //Create Array of Issued Books Details
        
        try (BufferedWriter bWriter = new BufferedWriter(new FileWriter("issuedBooksDetails.txt", true))){
            bWriter.write(String.join(",", issueBooksDetails)); //Save Issued Books Details To File
            bWriter.newLine();
            
            updateIssuedBookQuantity(bookDetails); //Update Book Quantity in Book Records
            
        } catch (IOException e){
            JOptionPane.showMessageDialog(null, "Error Saving Issued Book Details: "+e, 
                                          "Saving Error", JOptionPane.ERROR_MESSAGE);
            return; //Early Return Since There is Saving Error
        }
        
        JOptionPane.showMessageDialog(null, "Saved Issued Books Data Successfully",
                                      "Saving Success", JOptionPane.INFORMATION_MESSAGE); //Inform User of Saving Success
    }
    
    private void updateIssuedBookQuantity(String[] bookDetails){
        // UPDATE BOOK QUANTITY IN BOOK RECORDS
        //Declare Issued Book Details
        String bookID = bookDetails[0];
        String origQuantity = bookDetails[3];
        String issuedQuantity = "1";
        String totalQuantity;
        
        if (Integer.parseInt(origQuantity) <= 0){ //Check if origQuantity is <= 0
            //Inform User That Book is No Longer Available
            JOptionPane.showMessageDialog(null, "Book is No Longer Available\nPlease Wait For Others to Return Issued Books",
                                          "Availability Conflict", JOptionPane.WARNING_MESSAGE);
            return; //Early Return Since Book is Not Available
        }
        
        //Initialize origFile and tempFile
        File origFile = new File("booksDetails.txt");
        File tempFile = new File("tempBooksDetails.txt"); 
        try (BufferedReader bReader = new BufferedReader(new FileReader(origFile));
             BufferedWriter bWriter = new BufferedWriter(new FileWriter(tempFile))){
            String line;
            while((line = bReader.readLine()) != null){
                String[] lineDetails = line.split(",");
                
                if (lineDetails[0].equals(bookID)){ //Check if Recorded Book ID is same as Input
                    //Subtract one from the original quantity since we are issuing books
                    totalQuantity = Integer.toString(Integer.parseInt(origQuantity) - Integer.parseInt(issuedQuantity));
                    lineDetails[3] = totalQuantity; //Update the Quantity value

                    bWriter.write(String.join(",", lineDetails)); //Write updated line to file
                    bWriter.newLine(); //Add new line
                    continue; //Continue to next loop since current one is already written
                }
                //Write current line and add new line
                bWriter.write(line);
                bWriter.newLine();
                
            }
            //Close Reader and Writer to Allow File Deletion and Naming
            bReader.close();
            bWriter.close();
            
            if (origFile.delete()){ //Check if original file can be deleted
                tempFile.renameTo(origFile); //rename tempFile same as origFile
                JOptionPane.showMessageDialog(null, "Issued Successfully",
                                              "Issuance Success", JOptionPane.INFORMATION_MESSAGE); //Inform User of Issuance Success
            } else { //Inform user of Error Issuing
                JOptionPane.showMessageDialog(null, "Error Updating Book Quantity",
                                              "Issuance Failed", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (IOException e) { //Inform user of any Errors
            JOptionPane.showMessageDialog(null, "Error Issuing Books: "+e,
                                          "Issuance Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IssueBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IssueBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IssueBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IssueBooksPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new IssueBooksPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JPanel bookDetailsPanel;
    private javax.swing.JTextArea bookDetailsTextArea;
    private javax.swing.JLabel bookDetailsTitleLabel;
    private javax.swing.JLabel bookIDLabel;
    private javax.swing.JTextField bookIDTextField;
    private javax.swing.JLabel dueDateLabel;
    private javax.swing.JSpinner dueDateSpinner;
    private javax.swing.JButton findButton;
    private javax.swing.JButton issueBookButton;
    private javax.swing.JPanel issueBooksNavigationPanel;
    private javax.swing.JLabel issueBooksTitleLabel;
    private javax.swing.JLabel issueDateLabel;
    private javax.swing.JSpinner issueDateSpinner;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel memberDetailsPanel;
    private javax.swing.JTextArea memberDetailsTextArea;
    private javax.swing.JLabel memberDetailsTitleLabel;
    private javax.swing.JLabel memberIDLabel;
    private javax.swing.JTextField memberIDTextField;
    // End of variables declaration//GEN-END:variables
}
